import pygame

class Enemie(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()