import pygame

pygame.init()
screen = pygame.display.set_mode((1280, 720))
clock = pygame.time.Clock()
player = pygame.image.load("pildid/player.png")
floor = pygame.image.load("pildid/põrand1.png")
floor = pygame.transform.scale(floor, (1280,380))
player = pygame.transform.scale(player, (150,150))
playerRect = player.get_rect(midbottom=(480,480))

x_koordinaat = 480
y_koordinaat = 480

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            exit()
        key = pygame.key.get_pressed()

        if key[pygame.K_RIGHT]:
            x_koordinaat += 20
        if key[pygame.K_LEFT]:
            x_koordinaat -= 20

    screen.fill("Black")
    screen.blit(floor, (0, 360))
    screen.blit(player, (x_koordinaat, y_koordinaat))
    pygame.display.update()
    clock.tick(60)
