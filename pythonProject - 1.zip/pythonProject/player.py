import pygame
import sys
import os

class Player(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.images = []
        for i in range(1,16):
            img = pygame.image.load(os.path.join('pildid\run\cuphead_run_' + str(i)+'.png')).convert()
            self.images.append(img)
            self.player = self.images[0]
            self.rect = self.player.get_rect(midbottom=(480,480))
            self.player = pygame.transform.scale(player, (150,150))
            
        