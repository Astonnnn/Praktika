import pygame

class Game:
    pass