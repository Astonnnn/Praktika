import pygame

class Projectile(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()