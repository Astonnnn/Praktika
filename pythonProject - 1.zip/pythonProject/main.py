import pygame
import player

pygame.init()
screen = pygame.display.set_mode((1280, 720))
clock = pygame.time.Clock()
floor = pygame.image.load("pildid/floor1.png")
floor = pygame.transform.scale(floor, (1280,380))
player = Player() 
player_list = pygame.sprite.Group()
player_list.add(player)
backdropbox = screen.get_rect()




while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            exit()
        key = pygame.key.get_pressed()

        if key[pygame.K_RIGHT]:
            x_koordinaat += 20
        if key[pygame.K_LEFT]:
            x_koordinaat -= 20

    screen.fill("Black")
    screen.blit(floor, (0, 360))
    screen.blit(player, player_rect)
    pygame.display.update()
    clock.tick(60)
